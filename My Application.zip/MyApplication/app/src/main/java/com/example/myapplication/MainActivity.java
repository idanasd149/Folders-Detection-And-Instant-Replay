package com.example.myapplication;

import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.LinkedList;
import java.util.Queue;
import com.naman14.androidlame.AndroidLame;
import com.naman14.androidlame.LameBuilder;
public class MainActivity extends AppCompatActivity {

    private static final int SAMPLE_RATE = 44100;
    private static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO;
    private static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;
    private static final int BUFFER_SIZE = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT);
    private static final long MAX_DURATION_MS = 5 * 60 * 1000;

    private AudioRecord audioRecord;
    private boolean isRecording = false;
    private Thread recordingThread;
    private Queue<byte[]> audioDataQueue = new LinkedList<>();
    private long totalRecordedBytes = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startButton = findViewById(R.id.startButton);
        Button stopButton = findViewById(R.id.stopButton);
        Button saveButton = findViewById(R.id.saveButton);

        startButton.setOnClickListener(v -> startRecording());
        stopButton.setOnClickListener(v -> stopRecording());
        saveButton.setOnClickListener(v -> saveRecording());
    }

    private void startRecording() {
        if (!isRecording) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT, BUFFER_SIZE);
            audioRecord.startRecording();
            isRecording = true;
            Toast.makeText(this, "Recording started", Toast.LENGTH_SHORT).show();

            recordingThread = new Thread(() -> {
                while (isRecording) {
                    byte[] buffer = new byte[BUFFER_SIZE];
                    int bytesRead = audioRecord.read(buffer, 0, BUFFER_SIZE);
                    if (bytesRead > 0) {
                        audioDataQueue.add(buffer);
                        totalRecordedBytes += bytesRead;

                        // Remove old data to keep the last 5 minutes
                        while (totalRecordedBytes > MAX_DURATION_MS * SAMPLE_RATE * 2 / 1000) {
                            byte[] removedBuffer = audioDataQueue.poll();
                            if (removedBuffer != null) {
                                totalRecordedBytes -= removedBuffer.length;
                            }
                        }
                    }
                }
            });
            recordingThread.start();
        }
    }

    private void stopRecording() {
        if (isRecording) {
            isRecording = false;
            audioRecord.stop();
            audioRecord.release();
            audioRecord = null;
            Toast.makeText(this, "Recording stopped", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveRecording() {
        if (!isRecording) {
            String newFileName = "Recording_" + System.currentTimeMillis() + ".mp3";
            String newFilePath = getExternalFilesDir(Environment.DIRECTORY_MUSIC) + "/" + newFileName;
            File newFile = new File(newFilePath);

            AndroidLame androidLame = new LameBuilder()
                    .setInSampleRate(SAMPLE_RATE)
                    .setOutChannels(1)
                    .setOutBitrate(128)
                    .setOutSampleRate(SAMPLE_RATE)
                    .build();

            try (FileOutputStream fos = new FileOutputStream(newFile)) {
                int mp3BufferSize = BUFFER_SIZE * 2;
                byte[] mp3Buffer = new byte[mp3BufferSize];

                for (byte[] buffer : audioDataQueue) {
                    short[] shortBuffer = byteArrayToShortArray(buffer);
                    int bytesToWrite = androidLame.encode(shortBuffer, shortBuffer, shortBuffer.length / 2, mp3Buffer);
                    if (bytesToWrite > 0) {
                        fos.write(mp3Buffer, 0, bytesToWrite);
                    }
                }

                int outputMp3buf = androidLame.flush(mp3Buffer);
                if (outputMp3buf > 0) {
                    fos.write(mp3Buffer, 0, outputMp3buf);
                }
                androidLame.close();
                Toast.makeText(this, "Recording saved", Toast.LENGTH_SHORT).show();

                // Notify MediaStore about the new file
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, newFileName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MUSIC);
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 1);

                getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, contentValues);

                contentValues.clear();
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, contentValues, null, null);

            } catch (IOException e) {
                Toast.makeText(this, "Failed to save recording", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Recording is in progress", Toast.LENGTH_SHORT).show();
        }
    }

    private short[] byteArrayToShortArray(byte[] byteArray) {
        short[] shortArray = new short[byteArray.length / 2];
        ByteBuffer.wrap(byteArray).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shortArray);
        return shortArray;
    }


}

